
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/checkRoomAvailability")
public class RoomAvailabilityServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/roomdb";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String day = request.getParameter("day");
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");

        ArrayList<String> availableRooms = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            String sql =
                "SELECT r.room_name FROM rooms r WHERE r.room_id NOT IN (" +
                "SELECT b.room_id FROM bookings b WHERE b.day = ? " +
                "AND NOT (b.end_time <= ? OR b.start_time >= ?))";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, day);
            ps.setString(2, startTime);
            ps.setString(3, endTime);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                availableRooms.add(rs.getString("room_name"));
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("availableRooms", availableRooms);
        RequestDispatcher rd = request.getRequestDispatcher("roomAvailability.jsp");
        rd.forward(request, response);
    }
}
